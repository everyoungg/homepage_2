import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/WorkoutCategories.css';

const WorkoutCategories: React.FC = () => {
  const navigate = useNavigate();

  const categories = [
    {
      id: 'fullbody',
      name: '전신',
      icon: '🏃‍♂️',
      description: '전신을 골고루 운동'
    },
    {
      id: 'arms',
      name: '팔',
      icon: '💪',
      description: '상완이두근, 삼두근 운동'
    },
    {
      id: 'legs',
      name: '다리',
      icon: '🦵',
      description: '대퇴사두근, 햄스트링 운동'
    },
    {
      id: 'abs',
      name: '복부',
      icon: '🫁',
      description: '복근, 코어 운동'
    },
    {
      id: 'shoulders',
      name: '어깨',
      icon: '👤',
      description: '삼각근, 승모근 운동'
    },
    {
      id: 'chest',
      name: '가슴',
      icon: '💪',
      description: '대흉근, 소흉근 운동'
    }
  ];

  const handleCategoryClick = (categoryId: string) => {
    navigate(`/workout-exercises/${categoryId}`);
  };

  return (
    <div className="workout-categories-container">
      <div className="categories-header">
        <h1>운동 카테고리</h1>
        <p>원하는 부위를 선택해주세요</p>
      </div>

      <div className="categories-grid">
        {categories.map((category) => (
          <div
            key={category.id}
            className="category-card"
            onClick={() => handleCategoryClick(category.id)}
          >
            <div className="category-icon">{category.icon}</div>
            <div className="category-info">
              <h3>{category.name}</h3>
              <p>{category.description}</p>
            </div>
            <div className="category-arrow">→</div>
          </div>
        ))}
      </div>

      <button 
        onClick={() => navigate('/home')} 
        className="back-button"
      >
        홈으로 돌아가기
      </button>
    </div>
  );
};

export default WorkoutCategories; 