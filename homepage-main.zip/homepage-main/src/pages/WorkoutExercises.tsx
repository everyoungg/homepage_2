import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import '../styles/WorkoutExercises.css';

const WorkoutExercises: React.FC = () => {
  const navigate = useNavigate();
  const { categoryId } = useParams<{ categoryId: string }>();

  const exercises = {
    fullbody: [
      {
        id: 'burpees',
        name: '버피',
        description: '전신을 사용하는 고강도 운동',
        difficulty: '고급',
        duration: '10분'
      },
      {
        id: 'mountain_climbers',
        name: '마운틴 클라이머',
        description: '코어와 하체를 강화하는 운동',
        difficulty: '중급',
        duration: '8분'
      }
    ],
    arms: [
      {
        id: 'push_ups',
        name: '푸시업',
        description: '가슴과 팔을 강화하는 운동',
        difficulty: '중급',
        duration: '12분'
      },
      {
        id: 'diamond_push_ups',
        name: '다이아몬드 푸시업',
        description: '삼두근을 집중적으로 강화',
        difficulty: '고급',
        duration: '10분'
      }
    ],
    legs: [
      {
        id: 'squats',
        name: '스쿼트',
        description: '하체 근육을 강화하는 기본 운동',
        difficulty: '초급',
        duration: '15분'
      },
      {
        id: 'lunges',
        name: '런지',
        description: '균형감각과 하체 강화',
        difficulty: '중급',
        duration: '12분'
      }
    ],
    abs: [
      {
        id: 'crunches',
        name: '크런치',
        description: '복근을 집중적으로 강화',
        difficulty: '초급',
        duration: '10분'
      },
      {
        id: 'plank',
        name: '플랭크',
        description: '코어 안정성 향상',
        difficulty: '중급',
        duration: '8분'
      }
    ],
    shoulders: [
      {
        id: 'pike_push_ups',
        name: '파이크 푸시업',
        description: '어깨와 삼두근 강화',
        difficulty: '고급',
        duration: '10분'
      },
      {
        id: 'handstand_practice',
        name: '핸드스탠드 연습',
        description: '어깨 안정성과 균형감각 향상',
        difficulty: '고급',
        duration: '15분'
      }
    ],
    chest: [
      {
        id: 'wide_push_ups',
        name: '와이드 푸시업',
        description: '가슴 근육을 넓게 자극',
        difficulty: '중급',
        duration: '12분'
      },
      {
        id: 'decline_push_ups',
        name: '딥라인 푸시업',
        description: '상부 가슴 근육 강화',
        difficulty: '고급',
        duration: '10분'
      }
    ]
  };

  const categoryNames = {
    fullbody: '전신',
    arms: '팔',
    legs: '다리',
    abs: '복부',
    shoulders: '어깨',
    chest: '가슴'
  };

  const handleExerciseSelect = (exerciseId: string) => {
    navigate(`/workout-session/${categoryId}/${exerciseId}`);
  };

  const currentExercises = exercises[categoryId as keyof typeof exercises] || [];

  return (
    <div className="workout-exercises-container">
      <div className="exercises-header">
        <h1>{categoryNames[categoryId as keyof typeof categoryNames]} 운동</h1>
        <p>원하는 운동을 선택해주세요</p>
      </div>

      <div className="exercises-grid">
        {currentExercises.map((exercise) => (
          <div
            key={exercise.id}
            className="exercise-card"
            onClick={() => handleExerciseSelect(exercise.id)}
          >
            <div className="exercise-header">
              <h3>{exercise.name}</h3>
              <span className={`difficulty ${exercise.difficulty}`}>
                {exercise.difficulty}
              </span>
            </div>
            <p className="exercise-description">{exercise.description}</p>
            <div className="exercise-footer">
              <span className="duration">⏱️ {exercise.duration}</span>
              <div className="start-button">시작하기</div>
            </div>
          </div>
        ))}
      </div>

      <button 
        onClick={() => navigate('/workout-categories')} 
        className="back-button"
      >
        카테고리로 돌아가기
      </button>
    </div>
  );
};

export default WorkoutExercises; 